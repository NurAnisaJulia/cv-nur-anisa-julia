<!DOCTYPE html>
<html>
<head>
</head>
<body >
<table border="1">
				<tr>
					<th>NO.</th>
					<th>Legend</th>
					<th>Kegunaan</th>
				</tr>
				<tr>
					<td>1</td>
					<td>Daftar Arsip</td>
					<td>Daftar Kumpulan Arsip</td>
				</tr>
				<tr>
					<td>2</td>
					<td>Upload Arsip</td>
					<td>Menggunakan File arsip manual ke digital</td>
				</tr>
</table>
</body>
</html>
