<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Tampilan Menu</title>
</head>
<body>
<table class="table table-striped table-hover table-sm table-bordered">
	<thead class="thead-dark">
				<tr>
					<th>NO.</th>
					<th>Legend</th>
					<th>Kegunaan</th>
				</tr>
				<tr>
					<td>1</td>
					<td>Daftar Arsip</td>
					<td>Daftar Kumpulan Arsip</td>
				</tr>
			</tbody>
</table>
</body>
</html>
