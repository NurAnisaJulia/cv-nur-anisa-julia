<html>
  <head>
    <title>Curiculum Vitae</title>
 <style>
  .CV{
  width:500px;
        height:120px;
  top:10px;
        background:transparent url(CV.png) no-repeat top left;
  }
 </style>
  </head>
  <body>
    <h1 class="CV"></h1>
    <h2>Data Pribadi</h2>
    <table width="800px">
      <tbody>
        <tr>
          <td width="25%">Nama Lengkap</td>
          <td width="1%">:</td>
          <td>Nur Anisa Julia</td>
   <td rowspan="5" width="350px" align="left"><img src="22.jpg" alt="Me with nur" title="Me with nur" height="200px" width="150px"></td>
        </tr>
        <tr>
          <td>Tempat, Tanggal Lahir</td>
          <td>:</td>
          <td>Bandung, 10 Juli 2001</td>
        </tr>
        <tr>
          <td>Alamat</td>
          <td>:</td>
          <td>Jl. Bukit Jarian dlm rt 04 rw 011 , Cidadap, Bandung</td>
        </tr>
     <td>Email</td>
          <td>:</td>
          <td>anur93010@gmail.com</td>
        </tr>
      </tbody>
    </table>
  <h2>Pendidikan Formal</h2>
    <table width="800px">
      <tbody>
        <tr>
          <td>2017 - 2020</td>
          <td>:</td>
          <td>SMK AL-Falah Dago Bandung</td>
        </tr>
        <tr>
          <td>2014 - 2017</td>
          <td>:</td>
          <td>SMP AL-Husainiyyah Bandung</td>
        <tr>
          <td>2008 - 2014</td>
          <td>:</td>
          <td>SD AL-Husainiyyah Bandung</td>
        </tr>
        </tr>
        <tr>
          <td>2006 - 2008</td>
          <td>:</td>
          <td>TK Nur Iklas, Bandung </td>
        </tr>
      </tbody>
    </table>
  <h2>Pengalaman Kerja</h2>
    <table width="800px">
     <tbody>
        <tr>
          <td width="25%">01 April 2019 - 01 Juli 2019 </td>
          <td width="1%">:</td>
          <td>PKL di Pusat Survei Geologi</td>
        </tr>
      </tbody>
     </table>
<br><br>
</body>
</html>